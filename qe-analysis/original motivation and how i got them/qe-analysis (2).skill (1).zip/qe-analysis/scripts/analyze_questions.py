#!/usr/bin/env python3
"""
analyze_questions.py — Parse a question bank file and compute statistics.

Usage:
    python3 analyze_questions.py <question_bank.txt> [--output stats.json]

Detects the format automatically (Format A / B / C / D — see
references/parsing_patterns.md), counts sessions and topics, computes
averages, and emits a JSON file ready to feed into the generator scripts.

Output JSON structure:
{
  "format": "A",
  "total_questions": 695,
  "total_sessions": 14,
  "avg_q_per_exam": 49.6,
  "sessions": [
    {"session": "Normal", "year": "2017", "questions": 50},
    ...
  ],
  "topics": [
    {"topic": "tumeurs mammaires", "count": 95, "avg_per_exam": 6.79, "pct_of_exam": 13.6},
    ...
  ],
  "questions_by_topic": {
    "tumeurs mammaires": [
      {"session": "Normal", "year": "2017", "num": "1", "raw": "..."},
      ...
    ],
    ...
  }
}
"""
import argparse
import json
import re
import sys
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

# Format A — FMPM concours style: "# Normal 2017 Q1 - topic name"
PATTERN_A = re.compile(
    r'^# (?P<session>[A-Za-zéèêëûôîïÉÈÊËÛÔÎÏ]+) (?P<year>\d{4}) Q(?P<num>\d+) - (?P<topic>.+?)\s*$',
    re.MULTILINE
)

# Format B — Markdown header per topic, numbered items
PATTERN_B_HEADER = re.compile(r'^##+ (?P<topic>.+?)\s*$', re.MULTILINE)
PATTERN_B_QUESTION = re.compile(r'^\d+\.\s', re.MULTILINE)


def detect_format(text):
    """Return 'A', 'B', 'C', or 'D' based on which patterns match."""
    if len(PATTERN_A.findall(text)) >= 5:
        return 'A'
    if len(PATTERN_B_HEADER.findall(text)) > 3 and len(PATTERN_B_QUESTION.findall(text)) > 20:
        return 'B'
    # Format C and D detection would go here — for now, only A and B
    return 'D'


def parse_format_a(text):
    """Parse FMPM-style question bank file."""
    matches = list(PATTERN_A.finditer(text))
    if not matches:
        return None

    # Build sessions
    session_set = set()
    for m in matches:
        # Normalize session name (case-insensitive merge of Ratt/ratt)
        sess = m.group('session').strip().lower()
        year = m.group('year')
        session_set.add((sess, year))

    # Count questions per session
    session_counts = Counter()
    for m in matches:
        sess = m.group('session').strip().lower()
        year = m.group('year')
        session_counts[(sess, year)] += 1

    sessions = [
        {"session": s.capitalize(), "year": y, "questions": session_counts[(s, y)]}
        for (s, y) in sorted(session_set, key=lambda x: (x[1], x[0]))
    ]

    # Count questions per topic + collect raw question text for each
    topic_counts = Counter()
    questions_by_topic = defaultdict(list)

    # Split the text into per-question blocks so we can grab the raw text
    positions = [(m.start(), m) for m in matches]
    positions.append((len(text), None))

    for i in range(len(positions) - 1):
        start, m = positions[i]
        end, _ = positions[i + 1]
        if m is None:
            continue
        topic = m.group('topic').strip()
        topic_counts[topic] += 1
        raw_block = text[start:end].strip()
        questions_by_topic[topic].append({
            "session": m.group('session').capitalize(),
            "year": m.group('year'),
            "num": m.group('num'),
            "raw": raw_block
        })

    total_questions = sum(topic_counts.values())
    total_sessions = len(session_set)
    avg_q_per_exam = round(total_questions / total_sessions, 1) if total_sessions else 0

    # Build the topics list, sorted by count descending
    topics = []
    for topic, count in topic_counts.most_common():
        avg_per_exam = round(count / total_sessions, 2) if total_sessions else 0
        pct_of_exam = round(avg_per_exam / avg_q_per_exam * 100, 1) if avg_q_per_exam else 0
        topics.append({
            "topic": topic,
            "count": count,
            "avg_per_exam": avg_per_exam,
            "pct_of_exam": pct_of_exam
        })

    return {
        "format": "A",
        "total_questions": total_questions,
        "total_sessions": total_sessions,
        "avg_q_per_exam": avg_q_per_exam,
        "year_start": min(y for _, y in session_set),
        "year_end": max(y for _, y in session_set),
        "sessions": sessions,
        "topics": topics,
        "questions_by_topic": dict(questions_by_topic)
    }


def parse_format_b(text):
    """Parse markdown-header-per-topic format."""
    # Split by markdown headers
    sections = []
    current_topic = None
    current_lines = []
    for line in text.splitlines():
        m = PATTERN_B_HEADER.match(line)
        if m:
            if current_topic is not None:
                sections.append((current_topic, '\n'.join(current_lines)))
            current_topic = m.group('topic').strip()
            current_lines = []
        else:
            current_lines.append(line)
    if current_topic is not None:
        sections.append((current_topic, '\n'.join(current_lines)))

    topic_counts = Counter()
    questions_by_topic = defaultdict(list)
    for topic, body in sections:
        qs = PATTERN_B_QUESTION.findall(body)
        n = len(qs)
        if n:
            topic_counts[topic] += n
            # Format B has no session metadata; treat all as one session
            questions_by_topic[topic].append({
                "session": "Unknown",
                "year": "Unknown",
                "num": "?",
                "raw": body.strip()
            })

    total_questions = sum(topic_counts.values())
    topics = []
    for topic, count in topic_counts.most_common():
        topics.append({
            "topic": topic,
            "count": count,
            "avg_per_exam": count,  # only one session
            "pct_of_exam": 0
        })

    return {
        "format": "B",
        "total_questions": total_questions,
        "total_sessions": 1,
        "avg_q_per_exam": total_questions,
        "year_start": None,
        "year_end": None,
        "sessions": [],
        "topics": topics,
        "questions_by_topic": dict(questions_by_topic)
    }


def main():
    parser = argparse.ArgumentParser(description="Analyze a question bank file.")
    parser.add_argument("input", help="Path to the question bank .txt file")
    parser.add_argument("--output", "-o", default=None, help="Output JSON path (default: stdout)")
    args = parser.parse_args()

    in_path = Path(args.input)
    if not in_path.exists():
        sys.exit(f"ERROR: file not found: {in_path}")

    text = in_path.read_text(encoding="utf-8", errors="replace")
    fmt = detect_format(text)

    if fmt == 'A':
        result = parse_format_a(text)
    elif fmt == 'B':
        result = parse_format_b(text)
    else:
        sys.exit(f"ERROR: unrecognized format. Detected: {fmt}. "
                 f"See references/parsing_patterns.md for supported formats.")

    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        print(f"✓ Analysis written to {args.output}", file=sys.stderr)
        # Print a brief summary
        print(f"\n  Format: {result['format']}")
        print(f"  Total questions: {result['total_questions']}")
        print(f"  Total sessions:  {result['total_sessions']}")
        print(f"  Avg Q per exam:  {result['avg_q_per_exam']}")
        print(f"  Distinct topics: {len(result['topics'])}")
        print(f"\n  Top 10 topics:")
        for t in result['topics'][:10]:
            print(f"    {t['count']:4d} Q  ({t['avg_per_exam']:5.2f}/exam, {t['pct_of_exam']:5.1f}%)  {t['topic']}")
    else:
        print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
