#!/usr/bin/env python3
"""
generate_txt.py — Render the high-yield QE document as plain text from content.json.

Usage:
    python3 generate_txt.py <content.json> <output.txt>

See references/content_schema.md for the input JSON schema.
"""
import argparse
import json
import sys
from pathlib import Path


def banner_h(width=72, char='═'):
    return char * width


def banner_p(width=72, char='━'):
    return char * width


def write_header(c, lines):
    h = c['header']
    title = h['title']
    pad_left = (72 - len(title) - len(' — FICHES QE HAUTE FRÉQUENCE')) // 2
    lines.append(f"{title} — FICHES QE HAUTE FRÉQUENCE")
    lines.append(banner_h())
    lines.append(f"Synthèse par Claude.ai — Version {h['version']}")
    lines.append(f"Cross-match : {h['total_questions']} QEs officielles ({h['year_range']}) × {h['official_doc']}")
    lines.append(h['professors_line'])
    lines.append(banner_h())
    lines.append("")
    lines.append("")


def write_ranking_table(c, lines):
    lines.append(banner_p())
    lines.append("PARTIE 1 — CLASSEMENT DES LEÇONS PAR ORDRE D'IMPORTANCE DÉCROISSANTE")
    lines.append(banner_p())
    lines.append("")
    stats = c.get('stats', {})
    lines.append(f"Classement basé sur la fréquence réelle dans "
                 f"{stats.get('total_questions', '?')} QEs "
                 f"({stats.get('total_sessions', '?')} sessions).")
    lines.append("")
    lines.append("┌─────┬────────────────────────────────────────────────┬──────────┬─────────────────┐")
    lines.append("│ Rang│ Leçon officielle                               │ Total    │ Professeur      │")
    lines.append("├─────┼────────────────────────────────────────────────┼──────────┼─────────────────┤")
    for row in c['ranking_table']:
        rank = str(row['rank']).center(4)
        title = row['title'].ljust(46)[:46]
        total = row['count_label'].center(8)
        prof = (row.get('professor') or '—').ljust(15)[:15]
        lines.append(f"│ {rank}│ {title} │ {total} │ {prof} │")
    lines.append("└─────┴────────────────────────────────────────────────┴──────────┴─────────────────┘")
    lines.append("")
    lines.append("")


def write_averages_table(c, lines):
    lines.append(banner_p())
    lines.append("PARTIE 2 — MOYENNE DE QUESTIONS PAR LEÇON PAR EXAMEN")
    lines.append(banner_p())
    lines.append("")
    stats = c.get('stats', {})
    lines.append(f"Statistiques calculées sur {stats.get('total_sessions', '?')} sessions, "
                 f"chaque examen ~{stats.get('avg_q_per_exam', '?')} questions.")
    lines.append("")
    lines.append("┌────────────────────────────────────────────────┬────────┬──────────┬─────────┐")
    lines.append("│ Leçon officielle                               │ Total  │ Moy/exam │ % d'exam│")
    lines.append("├────────────────────────────────────────────────┼────────┼──────────┼─────────┤")
    for row in c['averages_table']:
        title = row['title'].ljust(46)[:46]
        total = row['total'].rjust(7)
        avg = row['avg'].center(9)
        pct = row['pct'].rjust(8)
        lines.append(f"│ {title} │ {total}│ {avg}│ {pct}│")
    if c.get('totals_row'):
        t = c['totals_row']
        lines.append("├────────────────────────────────────────────────┼────────┼──────────┼─────────┤")
        lines.append(f"│ {t['label'].ljust(46)[:46]} │ {t['total'].rjust(7)}│ {t['avg'].center(9)}│ {t['pct'].rjust(8)}│")
    lines.append("└────────────────────────────────────────────────┴────────┴──────────┴─────────┘")
    lines.append("")
    lines.append("")


def write_lesson_block(lesson, lines, is_hors=False):
    """Write a single [RANG N] block (or [HORS-N] block if is_hors=True)."""
    prefix = "HORS" if is_hors else "RANG"
    num = lesson.get('num') if is_hors else lesson['rank']

    lines.append(banner_h())
    lines.append(f"[{prefix} {num}] {lesson['title']}")

    if not is_hors:
        line2 = f"{lesson.get('professor', '—')} • {lesson['freq_label']}"
    else:
        line2 = lesson['freq_label']
    lines.append(line2)

    if lesson.get('oms_classification'):
        lines.append(f"📖 {lesson['oms_classification']}")
    for link in lesson.get('links', []) or []:
        label = link.get('label', 'Cours officiel')
        url = link.get('url', '')
        lines.append(f"📎 {label} : {url}")
    lines.append(banner_h())
    lines.append("")

    for entry in lesson.get('content', []):
        lines.append(f"* {entry['subtopic']}")
        for fact in entry.get('facts', []):
            lines.append(f"-{fact}")
        for warn in entry.get('warnings', []):
            lines.append(f"-⚠ {warn}")
        if entry.get('citations'):
            lines.append(f"📋 {entry['citations']}")
        lines.append("")
    lines.append("")


def write_partie_3(c, lines):
    lines.append(banner_p())
    lines.append("PARTIE 3 — QUESTIONS LES PLUS FRÉQUENTES (ORDRE STRICT PAR RANG)")
    lines.append("Format : faits (-) / pièges (⚠) / source (📖) / lien (📎) / citations (📋)")
    lines.append(banner_p())
    lines.append("")
    for lesson in c.get('in_program', []):
        write_lesson_block(lesson, lines, is_hors=False)


def write_partie_4(c, lines):
    lines.append(banner_p())
    lines.append(f"PARTIE 4 — TOPICS HORS LEÇONS OFFICIELLES {c.get('exam_year', '?')} (COURS ANNULÉ)")
    lines.append(banner_p())
    lines.append("")
    # Disclaimer box
    year = c.get('exam_year', '?')
    hpct = c.get('hors_program_pct', '?')
    disclaimer = [
        "╔══════════════════════════════════════════════════════════════════╗",
        "║  ⚠ DISCLAIMER — À LIRE AVANT D'UTILISER CETTE SECTION ⚠         ║",
        "║                                                                  ║",
        f"║  These lessons are NOT in the {str(year):<4} exam program.{' '*16}║",
        "║  Cours annulé — NOT officially scheduled.                        ║",
        "║                                                                  ║",
        "║  USE AT YOUR OWN RISK — BUT GOOD TO KNOW.                        ║",
        "║                                                                  ║",
        f"║  Ces topics représentaient historiquement ~{str(hpct):<4}% des questions  ║",
        "║  des examens passés. S'ils ne sont PAS au programme cette année, ║",
        "║  ils peuvent malgré tout apparaître en :                         ║",
        "║   • question résiduelle ou rattrapage                            ║",
        "║   • recyclage de dernière minute                                 ║",
        "║   • culture générale médicale                                    ║",
        "╚══════════════════════════════════════════════════════════════════╝",
    ]
    lines.extend(disclaimer)
    lines.append("")

    if not c.get('hors_program'):
        lines.append("(Aucun topic hors programme — tous les topics de la banque correspondent")
        lines.append(" aux leçons officielles cette année.)")
        lines.append("")
        return

    # Table
    lines.append(f"Topics hors programme {year} (classés par fréquence décroissante) :")
    lines.append("")
    lines.append("┌────────────────────────────────────────────────┬────────┬──────────┐")
    lines.append("│ Topic                                          │ Total  │ Moy/exam │")
    lines.append("├────────────────────────────────────────────────┼────────┼──────────┤")
    for row in c.get('hors_table', []):
        title = row['title'].ljust(46)[:46]
        total = row['total'].rjust(7)
        avg = row['avg'].center(9)
        lines.append(f"│ {title} │ {total}│ {avg}│")
    lines.append("└────────────────────────────────────────────────┴────────┴──────────┘")
    lines.append("")

    for lesson in c.get('hors_program', []):
        write_lesson_block(lesson, lines, is_hors=True)


def write_aide_memoire(c, lines):
    am = c.get('aide_memoire')
    if not am:
        return
    lines.append(banner_p())
    module = c.get('module_name', '')
    lines.append(f"AIDE-MÉMOIRE FINAL — HIGH-YIELD CONCOURS {module.upper()}")
    lines.append(banner_p())
    lines.append("")

    # Classifications
    if am.get('classifications'):
        lines.append(f"** {am.get('classifications_title', 'CLASSIFICATIONS')} **")
        for row in am['classifications']:
            lines.append(f"{row[0].ljust(20)}   →   {row[1]}")
        lines.append("")

    # Markers
    if am.get('markers'):
        lines.append(f"** {am.get('markers_title', 'MARQUEURS CLÉS')} **")
        for row in am['markers']:
            lines.append(f"{row[0].ljust(45)} → {row[1]}")
        lines.append("")

    # Pitfalls
    if am.get('pitfalls'):
        lines.append(f"** {am.get('pitfalls_title', 'PIÈGES CLASSIQUES')} **")
        for p in am['pitfalls']:
            lines.append(f"- {p}")
        lines.append("")

    # Sequences
    if am.get('sequences'):
        lines.append(f"** {am.get('sequences_title', 'SÉQUENCES CLÉS')} **")
        for s in am['sequences']:
            lines.append(s)
        lines.append("")


def write_footer(c, lines):
    f = c.get('footer', {})
    h = c['header']
    lines.append(banner_h())
    lines.append(f"Généré par Claude.ai ({f.get('model', 'unknown')}) — Version {f.get('version', '?')}")
    lines.append(f"Cross-match {h.get('total_questions', '?')} QEs officielles × {h.get('official_doc', '?')}")
    lines.append(h.get('professors_line', ''))
    if f.get('improvements'):
        lines.append("")
        lines.append(f"Améliorations Version {f.get('version', '?')} :")
        for imp in f['improvements']:
            lines.append(f"  ✓ {imp}")
    lines.append(banner_h())


def main():
    p = argparse.ArgumentParser()
    p.add_argument("content_json", help="Path to content.json")
    p.add_argument("output_txt", help="Path to output .txt file")
    args = p.parse_args()

    content = json.loads(Path(args.content_json).read_text(encoding='utf-8'))

    lines = []
    write_header(content, lines)
    write_ranking_table(content, lines)
    write_averages_table(content, lines)
    write_partie_3(content, lines)
    write_partie_4(content, lines)
    write_aide_memoire(content, lines)
    write_footer(content, lines)

    output = '\n'.join(lines) + '\n'
    Path(args.output_txt).write_text(output, encoding='utf-8')
    print(f"✓ Wrote {len(lines)} lines to {args.output_txt}", file=sys.stderr)


if __name__ == "__main__":
    main()
