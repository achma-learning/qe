#!/usr/bin/env node
/**
 * generate_docx.js — Render the QE document as .docx from content.json.
 *
 * Usage:
 *   node generate_docx.js <content.json> <output.docx>
 */

const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, AlignmentType,
        LevelFormat, BorderStyle, WidthType, ShadingType, HeadingLevel, PageBreak,
        ExternalHyperlink } = require('docx');
const fs = require('fs');
const path = require('path');

// ===== Theme =====
const C_PRIMARY = "1F3A5F";
const C_ACCENT = "8B0000";
const C_WARN = "B45309";
const C_OK = "065F46";
const C_LINK = "0563C1";
const C_GRAY = "404040";
const C_DANGER = "991B1B";

const border = { style: BorderStyle.SINGLE, size: 4, color: "B0B0B0" };
const cellBorders = { top: border, bottom: border, left: border, right: border };

// ===== Paragraph helpers =====
function H1(text) {
    return new Paragraph({
        heading: HeadingLevel.HEADING_1,
        children: [new TextRun({ text, bold: true, size: 32, color: C_PRIMARY, font: "Arial" })],
        spacing: { before: 360, after: 200 },
        border: { bottom: { style: BorderStyle.SINGLE, size: 12, color: C_PRIMARY, space: 4 } }
    });
}
function H2(text, color) {
    return new Paragraph({
        heading: HeadingLevel.HEADING_2,
        children: [new TextRun({ text, bold: true, size: 26, color: color || C_ACCENT, font: "Arial" })],
        spacing: { before: 240, after: 120 }
    });
}
function topicP(text) {
    return new Paragraph({
        children: [new TextRun({ text, bold: true, size: 22, underline: {}, color: C_ACCENT, font: "Arial" })],
        spacing: { before: 160, after: 60 }
    });
}
function factP(text) {
    return new Paragraph({
        numbering: { reference: "bullets", level: 0 },
        children: [new TextRun({ text, size: 20, font: "Arial" })],
        spacing: { before: 20, after: 20 }
    });
}
function warnP(text) {
    return new Paragraph({
        numbering: { reference: "bullets", level: 0 },
        children: [
            new TextRun({ text: "⚠ ", bold: true, color: C_WARN, size: 22 }),
            new TextRun({ text, size: 20, color: C_WARN, italics: true, font: "Arial" })
        ],
        spacing: { before: 20, after: 20 }
    });
}
function citationP(text) {
    return new Paragraph({
        children: [new TextRun({ text: "📋 " + text, italics: true, color: C_GRAY, size: 18, font: "Arial" })],
        spacing: { before: 20, after: 60 }
    });
}
function sourceP(text) {
    return new Paragraph({
        children: [new TextRun({ text: "📖 " + text, italics: true, color: C_GRAY, size: 20, font: "Arial" })],
        alignment: AlignmentType.CENTER,
        spacing: { before: 40, after: 40 }
    });
}
function linkP(label, url) {
    return new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 40, after: 80 },
        children: [
            new TextRun({ text: "📎 " + label + " : ", size: 20, color: C_GRAY, font: "Arial" }),
            new ExternalHyperlink({
                link: url,
                children: [new TextRun({
                    text: "Ouvrir le cours officiel ↗",
                    style: "Hyperlink", size: 20, color: C_LINK,
                    underline: { type: "single" }, font: "Arial"
                })]
            })
        ]
    });
}
function P(text, opts = {}) {
    return new Paragraph({
        children: [new TextRun({ text, size: opts.size || 20, bold: opts.bold || false,
                                  italics: opts.italics || false, color: opts.color || "000000",
                                  font: "Arial" })],
        spacing: { before: opts.before || 60, after: opts.after || 60 },
        alignment: opts.align || AlignmentType.LEFT
    });
}
function bannerP(text, color) {
    return new Paragraph({
        children: [new TextRun({ text, bold: true, size: 24, color: "FFFFFF", font: "Arial" })],
        alignment: AlignmentType.CENTER,
        shading: { fill: color || C_PRIMARY, type: ShadingType.CLEAR },
        spacing: { before: 240, after: 120 },
        border: { top: { style: BorderStyle.SINGLE, size: 8, color: color || C_PRIMARY },
                  bottom: { style: BorderStyle.SINGLE, size: 8, color: color || C_PRIMARY } }
    });
}
function cellC(text, opts = {}) {
    return new TableCell({
        borders: cellBorders,
        width: { size: opts.width || 2000, type: WidthType.DXA },
        shading: opts.shading ? { fill: opts.shading, type: ShadingType.CLEAR } : undefined,
        margins: { top: 80, bottom: 80, left: 120, right: 120 },
        children: [new Paragraph({
            children: [new TextRun({ text: String(text), size: opts.size || 18,
                                      bold: opts.bold || false, color: opts.color || "000000",
                                      font: "Arial" })],
            alignment: opts.align || AlignmentType.LEFT
        })]
    });
}

// ===== Renderers =====
function renderHeader(c, out) {
    const h = c.header;
    out.push(new Paragraph({
        children: [new TextRun({ text: h.title, bold: true, size: 44, color: C_PRIMARY, font: "Arial" })],
        alignment: AlignmentType.CENTER, spacing: { before: 0, after: 100 }
    }));
    out.push(new Paragraph({
        children: [new TextRun({ text: h.subtitle + " — Version " + h.version,
                                  bold: true, size: 30, color: C_ACCENT, font: "Arial" })],
        alignment: AlignmentType.CENTER, spacing: { before: 0, after: 240 },
        border: { bottom: { style: BorderStyle.DOUBLE, size: 12, color: C_PRIMARY, space: 4 } }
    }));
    out.push(P(`Cross-match : ${h.total_questions} QEs officielles (${h.year_range}) × ${h.official_doc}`,
               { italics: true, align: AlignmentType.CENTER, size: 20 }));
    out.push(P(h.professors_line, { align: AlignmentType.CENTER, size: 18, bold: true }));
}

function renderRankingTable(c, out) {
    out.push(bannerP("PARTIE 1 — CLASSEMENT DES LEÇONS PAR ORDRE D'IMPORTANCE"));
    const s = c.stats || {};
    out.push(P(`Classement basé sur la fréquence réelle dans ${s.total_questions} QEs (${s.total_sessions} sessions).`,
               { italics: true }));
    const cw = [800, 4800, 1400, 2360];
    out.push(new Table({
        width: { size: 9360, type: WidthType.DXA }, columnWidths: cw,
        rows: [
            new TableRow({ tableHeader: true, children: [
                cellC("Rang", { width: cw[0], shading: C_PRIMARY, color: "FFFFFF", bold: true, align: AlignmentType.CENTER }),
                cellC("Leçon officielle", { width: cw[1], shading: C_PRIMARY, color: "FFFFFF", bold: true }),
                cellC("Total", { width: cw[2], shading: C_PRIMARY, color: "FFFFFF", bold: true, align: AlignmentType.CENTER }),
                cellC("Professeur", { width: cw[3], shading: C_PRIMARY, color: "FFFFFF", bold: true })
            ]}),
            ...c.ranking_table.map((r, idx) => new TableRow({ children: [
                cellC(r.rank, { width: cw[0], align: AlignmentType.CENTER, bold: true,
                                 shading: idx % 2 ? "F0F0F0" : undefined }),
                cellC(r.title, { width: cw[1], shading: idx % 2 ? "F0F0F0" : undefined }),
                cellC(r.count_label, { width: cw[2], align: AlignmentType.CENTER, bold: true,
                                        color: C_ACCENT, shading: idx % 2 ? "F0F0F0" : undefined }),
                cellC(r.professor || '—', { width: cw[3], shading: idx % 2 ? "F0F0F0" : undefined })
            ]}))
        ]
    }));
}

function renderAveragesTable(c, out) {
    out.push(new Paragraph({ children: [new PageBreak()] }));
    out.push(bannerP("PARTIE 2 — MOYENNE DE QUESTIONS PAR LEÇON PAR EXAMEN"));
    const s = c.stats || {};
    out.push(P(`Statistiques calculées sur ${s.total_sessions} sessions, chaque examen ~${s.avg_q_per_exam} questions.`,
               { italics: true }));
    const cw = [4400, 1400, 1700, 1860];
    const rows = [
        new TableRow({ tableHeader: true, children: [
            cellC("Leçon officielle", { width: cw[0], shading: C_PRIMARY, color: "FFFFFF", bold: true }),
            cellC("Total", { width: cw[1], shading: C_PRIMARY, color: "FFFFFF", bold: true, align: AlignmentType.CENTER }),
            cellC("Moy/exam", { width: cw[2], shading: C_PRIMARY, color: "FFFFFF", bold: true, align: AlignmentType.CENTER }),
            cellC("% d'exam", { width: cw[3], shading: C_PRIMARY, color: "FFFFFF", bold: true, align: AlignmentType.CENTER })
        ]}),
        ...c.averages_table.map((r, idx) => new TableRow({ children: [
            cellC(r.title, { width: cw[0], shading: idx % 2 ? "F0F0F0" : undefined }),
            cellC(r.total, { width: cw[1], align: AlignmentType.CENTER, shading: idx % 2 ? "F0F0F0" : undefined }),
            cellC(r.avg, { width: cw[2], align: AlignmentType.CENTER, bold: true,
                            color: C_ACCENT, shading: idx % 2 ? "F0F0F0" : undefined }),
            cellC(r.pct, { width: cw[3], align: AlignmentType.CENTER, bold: true,
                            shading: idx % 2 ? "F0F0F0" : undefined })
        ]}))
    ];
    if (c.totals_row) {
        const t = c.totals_row;
        rows.push(new TableRow({ children: [
            cellC(t.label, { width: cw[0], shading: "FFF3E0", bold: true }),
            cellC(t.total, { width: cw[1], align: AlignmentType.CENTER, shading: "FFF3E0", bold: true }),
            cellC(t.avg, { width: cw[2], align: AlignmentType.CENTER, shading: "FFF3E0", bold: true, color: C_ACCENT }),
            cellC(t.pct, { width: cw[3], align: AlignmentType.CENTER, shading: "FFF3E0", bold: true, color: C_ACCENT })
        ]}));
    }
    out.push(new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: cw, rows: rows }));
}

function renderLessonBlock(lesson, out, isHors) {
    const prefix = isHors ? "HORS" : "RANG";
    const num = isHors ? lesson.num : lesson.rank;
    out.push(H1(`[${prefix} ${num}] ${lesson.title}`));
    const line2 = isHors
        ? lesson.freq_label
        : `${lesson.professor || '—'}  •  ${lesson.freq_label}`;
    out.push(P(line2, { align: AlignmentType.CENTER, italics: true, bold: true, size: 22, color: C_ACCENT }));
    if (lesson.oms_classification) {
        out.push(sourceP(lesson.oms_classification));
    }
    (lesson.links || []).forEach(l => out.push(linkP(l.label || "Cours officiel", l.url)));
    (lesson.content || []).forEach(entry => {
        out.push(topicP(entry.subtopic));
        (entry.facts || []).forEach(f => out.push(factP(f)));
        (entry.warnings || []).forEach(w => out.push(warnP(w)));
        if (entry.citations) out.push(citationP(entry.citations));
    });
}

function renderPartie3(c, out) {
    out.push(new Paragraph({ children: [new PageBreak()] }));
    out.push(bannerP("PARTIE 3 — QUESTIONS LES PLUS FRÉQUENTES (ORDRE STRICT PAR RANG)"));
    out.push(P("Format : faits (-) / pièges (⚠) / source (📖) / lien cours (📎) / citations (📋)",
               { italics: true, align: AlignmentType.CENTER }));
    (c.in_program || []).forEach(lesson => renderLessonBlock(lesson, out, false));
}

function renderPartie4(c, out) {
    out.push(new Paragraph({ children: [new PageBreak()] }));
    const year = c.exam_year || '?';
    const hpct = c.hors_program_pct != null ? c.hors_program_pct : '?';
    out.push(bannerP(`PARTIE 4 — TOPICS HORS LEÇONS OFFICIELLES ${year} (COURS ANNULÉ)`, C_DANGER));

    // Disclaimer box
    out.push(new Paragraph({
        spacing: { before: 200, after: 80 },
        shading: { fill: "FEF2F2", type: ShadingType.CLEAR },
        border: {
            top: { style: BorderStyle.SINGLE, size: 16, color: C_DANGER },
            left: { style: BorderStyle.SINGLE, size: 16, color: C_DANGER },
            bottom: { style: BorderStyle.SINGLE, size: 16, color: C_DANGER },
            right: { style: BorderStyle.SINGLE, size: 16, color: C_DANGER }
        },
        children: [new TextRun({ text: "⚠ DISCLAIMER — À LIRE AVANT D'UTILISER CETTE SECTION ⚠",
                                  bold: true, size: 26, color: C_DANGER, font: "Arial" })],
        alignment: AlignmentType.CENTER
    }));
    out.push(P(`These lessons are NOT in the ${year} exam program.`,
               { bold: true, size: 22, color: C_DANGER, align: AlignmentType.CENTER }));
    out.push(P("Cours annulé — NOT officially scheduled.",
               { bold: true, size: 22, color: C_DANGER, align: AlignmentType.CENTER }));
    out.push(P("USE AT YOUR OWN RISK — BUT GOOD TO KNOW.",
               { bold: true, size: 24, color: C_DANGER, align: AlignmentType.CENTER, before: 80, after: 120 }));
    out.push(P(`Ces topics représentaient historiquement ~${hpct}% des questions des examens passés. ` +
               "S'ils ne sont PAS au programme cette année, ils peuvent malgré tout :",
               { italics: true, before: 120 }));
    ["Apparaître en question résiduelle ou rattrapage",
     "Être recyclés à la dernière minute",
     "Servir de \"culture générale\" médicale"].forEach(t => out.push(factP(t)));

    if (!c.hors_program || c.hors_program.length === 0) {
        out.push(P("(Aucun topic hors programme — tous les topics correspondent aux leçons officielles cette année.)",
                   { italics: true, color: C_GRAY, align: AlignmentType.CENTER, before: 200 }));
        return;
    }

    // HORS topics table
    out.push(P(`Topics hors programme ${year} (par fréquence décroissante) :`, { bold: true, before: 200 }));
    const cw = [5500, 1600, 2260];
    out.push(new Table({
        width: { size: 9360, type: WidthType.DXA }, columnWidths: cw,
        rows: [
            new TableRow({ tableHeader: true, children: [
                cellC("Topic (hors programme)", { width: cw[0], shading: C_DANGER, color: "FFFFFF", bold: true }),
                cellC("Total", { width: cw[1], shading: C_DANGER, color: "FFFFFF", bold: true, align: AlignmentType.CENTER }),
                cellC("Moy/exam", { width: cw[2], shading: C_DANGER, color: "FFFFFF", bold: true, align: AlignmentType.CENTER })
            ]}),
            ...(c.hors_table || []).map((r, idx) => new TableRow({ children: [
                cellC(r.title, { width: cw[0], shading: idx % 2 ? "FEF2F2" : undefined }),
                cellC(r.total, { width: cw[1], align: AlignmentType.CENTER, shading: idx % 2 ? "FEF2F2" : undefined }),
                cellC(r.avg, { width: cw[2], align: AlignmentType.CENTER, bold: true,
                                color: C_DANGER, shading: idx % 2 ? "FEF2F2" : undefined })
            ]}))
        ]
    }));

    (c.hors_program || []).forEach(lesson => renderLessonBlock(lesson, out, true));
}

function renderAideMemoire(c, out) {
    const am = c.aide_memoire;
    if (!am) return;
    out.push(new Paragraph({ children: [new PageBreak()] }));
    const module = c.module_name || '';
    out.push(bannerP(`AIDE-MÉMOIRE FINAL — HIGH-YIELD CONCOURS ${module.toUpperCase()}`));

    if (am.classifications && am.classifications.length) {
        out.push(H2(`** ${am.classifications_title || 'CLASSIFICATIONS'} **`));
        out.push(new Table({
            width: { size: 9360, type: WidthType.DXA }, columnWidths: [4680, 4680],
            rows: am.classifications.map((r, idx) => new TableRow({ children: [
                cellC(r[0], { width: 4680, bold: true, shading: idx % 2 ? "F0F0F0" : undefined }),
                cellC(r[1], { width: 4680, bold: true, color: C_ACCENT, shading: idx % 2 ? "F0F0F0" : undefined })
            ]}))
        }));
    }

    if (am.markers && am.markers.length) {
        out.push(H2(`** ${am.markers_title || 'MARQUEURS CLÉS'} **`));
        out.push(new Table({
            width: { size: 9360, type: WidthType.DXA }, columnWidths: [4500, 4860],
            rows: [
                new TableRow({ tableHeader: true, children: [
                    cellC("Marqueur / Critère", { width: 4500, shading: C_PRIMARY, color: "FFFFFF", bold: true }),
                    cellC("Indication", { width: 4860, shading: C_PRIMARY, color: "FFFFFF", bold: true })
                ]}),
                ...am.markers.map((r, idx) => new TableRow({ children: [
                    cellC(r[0], { width: 4500, bold: true, shading: idx % 2 ? "F0F0F0" : undefined }),
                    cellC(r[1], { width: 4860, shading: idx % 2 ? "F0F0F0" : undefined })
                ]}))
            ]
        }));
    }

    if (am.pitfalls && am.pitfalls.length) {
        out.push(H2(`** ${am.pitfalls_title || 'PIÈGES CLASSIQUES'} **`));
        am.pitfalls.forEach(t => out.push(warnP(t)));
    }
    if (am.sequences && am.sequences.length) {
        out.push(H2(`** ${am.sequences_title || 'SÉQUENCES CLÉS'} **`));
        am.sequences.forEach(t => out.push(factP(t)));
    }
}

function renderFooter(c, out) {
    const f = c.footer || {};
    const h = c.header || {};
    out.push(P(" ", { before: 240 }));
    out.push(new Paragraph({
        border: { top: { style: BorderStyle.DOUBLE, size: 8, color: C_PRIMARY, space: 4 } },
        children: [new TextRun({ text: "" })]
    }));
    out.push(P(`Généré par Claude.ai (${f.model || 'unknown'}) — Version ${f.version || '?'}`,
               { italics: true, align: AlignmentType.CENTER, size: 18 }));
    out.push(P(`Cross-match ${h.total_questions} QEs officielles × ${h.official_doc}`,
               { italics: true, align: AlignmentType.CENTER, size: 18 }));
    out.push(P(h.professors_line || '', { italics: true, align: AlignmentType.CENTER, size: 18, bold: true }));
    if (f.improvements && f.improvements.length) {
        out.push(P(`Améliorations Version ${f.version || '?'} :`, { bold: true, color: C_OK, before: 200 }));
        f.improvements.forEach(t => out.push(P("✓ " + t, { color: C_OK, size: 18 })));
    }
}

// ===== Main =====
function main() {
    const [contentPath, outputPath] = process.argv.slice(2);
    if (!contentPath || !outputPath) {
        console.error("Usage: node generate_docx.js <content.json> <output.docx>");
        process.exit(1);
    }
    const content = JSON.parse(fs.readFileSync(contentPath, 'utf-8'));
    const out = [];

    renderHeader(content, out);
    renderRankingTable(content, out);
    renderAveragesTable(content, out);
    renderPartie3(content, out);
    renderPartie4(content, out);
    renderAideMemoire(content, out);
    renderFooter(content, out);

    const doc = new Document({
        creator: "Claude.ai",
        title: content.header.title + " - QE Haute Fréquence",
        description: "Generated by qe-analysis skill",
        styles: {
            default: { document: { run: { font: "Arial", size: 20 } } },
            paragraphStyles: [
                { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
                  run: { size: 32, bold: true, font: "Arial", color: C_PRIMARY },
                  paragraph: { spacing: { before: 360, after: 200 }, outlineLevel: 0 } },
                { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
                  run: { size: 26, bold: true, font: "Arial", color: C_ACCENT },
                  paragraph: { spacing: { before: 240, after: 120 }, outlineLevel: 1 } },
            ]
        },
        numbering: {
            config: [{
                reference: "bullets",
                levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
                           style: { paragraph: { indent: { left: 720, hanging: 360 } } } }]
            }]
        },
        sections: [{
            properties: {
                page: {
                    size: { width: 12240, height: 15840 },
                    margin: { top: 1080, right: 1080, bottom: 1080, left: 1080 }
                }
            },
            children: out
        }]
    });

    Packer.toBuffer(doc).then(buffer => {
        fs.writeFileSync(outputPath, buffer);
        console.error(`✓ Wrote ${buffer.length} bytes to ${outputPath}`);
    });
}

main();
