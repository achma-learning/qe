#!/usr/bin/env python3
"""
match_lessons.py — Cross-match question-bank topics against official lessons.

DOMAIN-AGNOSTIC. The script doesn't know what subject you're analyzing.
For best results, pass a synonyms file with the vocabulary of YOUR domain.
Without one, the script falls back to pure normalization + Jaccard scoring
(works decently for most cases but misses field-specific synonyms).

Usage:
    python3 match_lessons.py <analysis.json> <lessons.json> [options]

Options:
    --output <path>        Save full output JSON
    --synonyms <path>      Load a synonyms JSON file (see schema below)
    --accept-threshold <f> Auto-accept above this score (default 0.75)
    --review-threshold <f> Below this even accepted matches are flagged (default 0.90)

Synonyms file schema:
    {
        "domain": "human-readable label (e.g. 'French medical', 'Common law')",
        "noise_words": ["tumeur", "cancer", "..."],   // words to STRIP before matching
        "synonyms": [
            ["sein", "mammaire", "mammaires"],         // each sublist = equivalent terms
            ["foie", "hepatique"],
            ...
        ]
    }

The output JSON adds three keys to the analysis:
    "lessons_in_program":     topics matched to an official lesson
    "lessons_hors_program":   topics that didn't match
    "ambiguous_matches":      borderline matches needing user confirmation
"""
import argparse
import json
import re
import sys
import unicodedata
from difflib import SequenceMatcher
from pathlib import Path


# ===== Built-in generic noise words (apply to ANY domain) =====
GENERIC_NOISE = {
    'le', 'la', 'les', 'des', 'du', 'de', 'd', 'l',
    'et', 'ou', 'a', 'au', 'aux', 'en', 'sur', 'par', 'pour',
    'the', 'a', 'an', 'of', 'in', 'on', 'and', 'or',
}

# Generic prefixes worth stripping (still domain-neutral)
GENERIC_PREFIXES = [
    'pathologie de la', "pathologie de l", 'pathologie du',
    'maladie de', 'maladies de',
    "lesions de la", "lesions de l",
    'devant une', 'devant un',
    'introduction a', 'introduction au',
    'chapitre',
]


def strip_accents(s):
    return ''.join(c for c in unicodedata.normalize('NFD', s)
                   if unicodedata.category(c) != 'Mn')


def stem_word(w):
    """Crude stemming. Domain-agnostic — just removes common French/English suffixes."""
    if len(w) <= 3:
        return w
    for suf in ['eaux', 'aux', 'ales', 'ives', 'ifs', 'ique', 'iques',
                'iens', 'ienne', 'iennes', 'eux', 'euses', 'euse',
                'ment', 'ments', 'tion', 'tions', 'sion', 'sions',
                'able', 'ables', 'ible', 'ibles',
                'ing', 'tion', 'sion']:
        if w.endswith(suf) and len(w) > len(suf) + 2:
            return w[:-len(suf)]
    if w.endswith('s') and len(w) > 4:
        w = w[:-1]
    if w.endswith('e') and len(w) > 4:
        w = w[:-1]
    return w


def load_synonyms(path):
    """Load a synonyms file. Returns (noise_words_set, synonym_lookup_dict, synonym_sets_list)."""
    data = json.loads(Path(path).read_text(encoding='utf-8'))
    noise = set(strip_accents(w.lower()) for w in data.get('noise_words', []))
    synonym_sets = []
    lookup = {}
    for syn_set in data.get('synonyms', []):
        normed = set(strip_accents(w.lower().replace('-', ' ').replace("'", " ")) for w in syn_set)
        synonym_sets.append(normed)
        canonical = sorted(normed)[0]
        for w in normed:
            lookup[w] = canonical
    return noise, lookup, synonym_sets


def canonicalize(s, noise_words, synonym_lookup, synonym_sets):
    """Reduce a string to a SET of canonical content words."""
    s = strip_accents(s.lower().strip())
    s = s.replace("'", " ").replace("'", " ").replace("'", " ").replace("-", " ")
    for prefix in sorted(GENERIC_PREFIXES, key=len, reverse=True):
        if s.startswith(prefix + ' '):
            s = s[len(prefix) + 1:]
            break
    s = re.sub(r"[^\w\s]", ' ', s)
    bag = set()
    for w in s.split():
        if w in GENERIC_NOISE or w in noise_words:
            continue
        # Try as-is in synonym lookup
        if w in synonym_lookup:
            bag.add(synonym_lookup[w])
            continue
        # Try stemmed
        stemmed = stem_word(w)
        if stemmed in synonym_lookup:
            bag.add(synonym_lookup[stemmed])
            continue
        # Try stem-level match against synonym set members
        found = False
        for syn_set in synonym_sets:
            for syn_w in syn_set:
                if stem_word(syn_w) == stemmed:
                    bag.add(sorted(syn_set)[0])
                    found = True
                    break
            if found:
                break
        if not found:
            bag.add(stemmed)
    return bag


def fuzzy_score(a, b, noise_words, synonym_lookup, synonym_sets):
    """Symmetric similarity in [0, 1]."""
    sa = canonicalize(a, noise_words, synonym_lookup, synonym_sets)
    sb = canonicalize(b, noise_words, synonym_lookup, synonym_sets)
    if not sa or not sb:
        return 0.0
    if sa == sb:
        return 1.0
    intersection = sa & sb
    union = sa | sb
    jaccard = len(intersection) / len(union)
    containment = len(intersection) / min(len(sa), len(sb))
    char_sim = SequenceMatcher(None, ' '.join(sorted(sa)), ' '.join(sorted(sb))).ratio()
    return max(jaccard, containment * 0.85, char_sim * 0.5)


def match_topic_to_lesson(topic, lessons, noise, lookup, sets, accept_threshold):
    best = (None, 0.0)
    for lesson in lessons:
        score = fuzzy_score(topic, lesson['title'], noise, lookup, sets)
        if score > best[1]:
            best = (lesson, score)
    if best[1] >= accept_threshold:
        return best
    return (None, best[1])


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("analysis", help="Path to analysis.json from analyze_questions.py")
    parser.add_argument("lessons", help="Path to lessons.json (the official lessons list)")
    parser.add_argument("--output", "-o", default=None, help="Output path (default: stdout)")
    parser.add_argument("--synonyms", "-s", default=None,
                        help="Optional synonyms JSON file (see schema in module docstring)")
    parser.add_argument("--accept-threshold", type=float, default=0.75)
    parser.add_argument("--review-threshold", type=float, default=0.90)
    args = parser.parse_args()

    analysis = json.loads(Path(args.analysis).read_text(encoding='utf-8'))
    lessons = json.loads(Path(args.lessons).read_text(encoding='utf-8'))

    if args.synonyms:
        noise, lookup, sets = load_synonyms(args.synonyms)
        domain_label = json.loads(Path(args.synonyms).read_text(encoding='utf-8')).get('domain', 'custom')
        print(f"  Loaded synonyms file: {args.synonyms} (domain: {domain_label})", file=sys.stderr)
        print(f"    {len(noise)} noise words, {len(sets)} synonym sets", file=sys.stderr)
    else:
        noise, lookup, sets = set(), {}, []
        print("  No synonyms file — using generic normalization only.", file=sys.stderr)
        print("  For better matching, pass --synonyms with a domain-specific file.", file=sys.stderr)

    in_program, hors_program, ambiguous = [], [], []
    for topic in analysis['topics']:
        matched, score = match_topic_to_lesson(
            topic['topic'], lessons, noise, lookup, sets, args.accept_threshold
        )
        if matched is not None:
            entry = dict(topic, official_title=matched['title'],
                         professor=matched.get('professor', '—'),
                         link=matched.get('link'),
                         match_score=round(score, 3))
            in_program.append(entry)
            if score < args.review_threshold:
                ambiguous.append({
                    "question_bank_topic": topic['topic'],
                    "matched_to": matched['title'],
                    "score": round(score, 3),
                    "decision": "needs user confirmation"
                })
        else:
            entry = dict(topic, professor=None, link=None,
                         best_unmatched_score=round(score, 3))
            hors_program.append(entry)

    in_program.sort(key=lambda x: -x['count'])
    hors_program.sort(key=lambda x: -x['count'])
    for i, t in enumerate(in_program, 1):
        t['rank'] = i

    total_in = sum(t['count'] for t in in_program)
    total_hors = sum(t['count'] for t in hors_program)
    total_all = total_in + total_hors
    hors_pct = round(total_hors / total_all * 100, 1) if total_all else 0
    in_pct = round(total_in / total_all * 100, 1) if total_all else 0
    matched_titles = {t['official_title'] for t in in_program}
    lessons_no_questions = [l['title'] for l in lessons if l['title'] not in matched_titles]

    output = dict(analysis,
                  lessons_in_program=in_program,
                  lessons_hors_program=hors_program,
                  ambiguous_matches=ambiguous,
                  summary={
                      "in_program_count": len(in_program),
                      "in_program_total_questions": total_in,
                      "in_program_pct": in_pct,
                      "hors_program_count": len(hors_program),
                      "hors_program_total_questions": total_hors,
                      "hors_program_pct": hors_pct,
                      "lessons_provided": len(lessons),
                      "lessons_with_no_questions": lessons_no_questions,
                  })

    if args.output:
        Path(args.output).write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding='utf-8')
        print(f"\n✓ Match results written to {args.output}", file=sys.stderr)
    else:
        print(json.dumps(output, ensure_ascii=False, indent=2))

    print(f"\n  In-program: {len(in_program)} topics, {total_in} Q ({in_pct}%)", file=sys.stderr)
    print(f"  HORS:       {len(hors_program)} topics, {total_hors} Q ({hors_pct}%)", file=sys.stderr)
    if ambiguous:
        print(f"\n  ⚠ {len(ambiguous)} ambiguous match(es) — please review:", file=sys.stderr)
        for a in ambiguous:
            print(f"     [{a['score']:.2f}]  \"{a['question_bank_topic']}\"  →  \"{a['matched_to']}\"", file=sys.stderr)
    if lessons_no_questions:
        print(f"\n  ℹ Official lessons with NO matching question-bank topic:", file=sys.stderr)
        for t in lessons_no_questions:
            print(f"     - {t}", file=sys.stderr)


if __name__ == "__main__":
    main()
