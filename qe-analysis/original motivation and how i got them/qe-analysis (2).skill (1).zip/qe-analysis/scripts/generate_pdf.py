#!/usr/bin/env python3
"""
generate_pdf.py — Convert a .docx to .pdf via LibreOffice headless.

Usage:
    python3 generate_pdf.py <input.docx> <output.pdf>

This wraps `soffice --headless --convert-to pdf`. Hyperlinks in the .docx
are preserved as clickable links in the .pdf.
"""
import argparse
import subprocess
import sys
import shutil
from pathlib import Path


def find_soffice():
    """Locate the LibreOffice executable. Fall back to the helper if present."""
    helper = Path("/mnt/skills/public/docx/scripts/office/soffice.py")
    if helper.exists():
        return ["python3", str(helper)]
    for name in ["soffice", "libreoffice"]:
        path = shutil.which(name)
        if path:
            return [path]
    sys.exit("ERROR: neither soffice nor /mnt/skills/public/docx/scripts/office/soffice.py found.")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("input_docx", help="Path to input .docx")
    p.add_argument("output_pdf", help="Path to output .pdf")
    args = p.parse_args()

    in_path = Path(args.input_docx).resolve()
    out_path = Path(args.output_pdf).resolve()
    if not in_path.exists():
        sys.exit(f"ERROR: input not found: {in_path}")
    out_dir = out_path.parent
    out_dir.mkdir(parents=True, exist_ok=True)

    cmd = find_soffice() + [
        "--headless", "--convert-to", "pdf",
        str(in_path), "--outdir", str(out_dir)
    ]
    print(f"Running: {' '.join(cmd)}", file=sys.stderr)
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        sys.exit(f"ERROR: conversion failed.\nstdout: {result.stdout}\nstderr: {result.stderr}")

    # LibreOffice names the PDF as <basename>.pdf in the outdir.
    generated = out_dir / (in_path.stem + ".pdf")
    if generated != out_path:
        if generated.exists():
            shutil.move(str(generated), str(out_path))
        else:
            sys.exit(f"ERROR: expected output not found at {generated}")
    size = out_path.stat().st_size
    print(f"✓ Wrote {size} bytes to {out_path}", file=sys.stderr)


if __name__ == "__main__":
    main()
