---
name: qe-analysis
description: Analyze a corpus of past exam questions (QEs - questions d'examen) from ANY domain — medical specialties (anapath, cardio, gastro, traumato, gynéco, pharmaco), legal exams, engineering, history, sciences, etc. — and produce a high-yield, deduplicated, ranked study document cross-matched against the year's official lesson program. Use this skill whenever the user uploads a question bank file (named like "Anapath 2.txt", "QE Cardio.txt", "droit_civil.txt") or asks to analyze QEs, rank lessons by frequency, build a high-yield study guide from past exams, find most frequent questions, summarize repeated questions with all their corrections, or list common pitfalls. Trigger even on short prompts like "analyze my exam questions". The skill auto-adapts to the domain — Claude detects the subject, picks or builds the right vocabulary/synonyms, and chooses the optimal cheatsheet structure for that field.
---

# QE Analysis Skill — domain-agnostic

A workflow for turning a corpus of past exam questions into a deduplicated, ranked, cross-matched high-yield study document. **Works for any subject.** Claude adapts the approach to whatever domain you're analyzing.

## What this skill is

A **procedural framework**, not a content library. The skill provides :
- Scripts to parse question banks (any format with topic tags)
- A cross-matcher with pluggable domain vocabulary
- Renderers for `.txt`, `.docx`, `.pdf`

You (Claude) bring :
- Domain knowledge (medical / legal / engineering / etc.)
- Synthesis of the high-yield content
- Judgment about what aide-mémoire structure fits the field

## Output structure (universal, regardless of domain)

| Section | Content |
|---|---|
| **PARTIE 1** | Lessons ranked by frequency (descending) — table |
| **PARTIE 2** | Average questions per topic per exam |
| **PARTIE 3** | Deduplicated high-yield Q&A per topic, in strict rank order (1→N) |
| **PARTIE 4** | Topics HORS programme (cours annulé) — with mandatory disclaimer |
| **Aide-mémoire** | Cross-cutting cheatsheet — slot labels adapted to the domain |

The user picks the export format (`.txt`, `.docx`, or `.pdf`).

## When to trigger

- User uploads a file with many past exam questions tagged by topic
- User asks to analyze QEs, rank by frequency, build a study guide from past papers
- User wants deduplication of repeated questions with consolidated corrections

**Don't trigger** for single questions, MCQ grading, or short Q&A pairs.

---

## The workflow — 7 steps

### Step 0 — Identify the domain (CRITICAL — do this first)

Before anything else, figure out what subject the question bank covers. Signals :

- Filename (`cardio_QE.txt`, `Anapath 2.txt`, `droit_civil.txt`, `physics_finals.txt`)
- Sample 5-10 question texts — the vocabulary tells you the domain
- Topic names — if they're "Cancer du sein, Tumeurs hépatiques…" it's clearly medical oncology
- If unclear, **ask**:
  > "Pour cette banque de questions, quel est le domaine exact ? (médecine — quelle spécialité, droit, ingénierie, histoire, …)"

Set this domain identifier in the final `content.json` as `module_name`. It drives the aide-mémoire framing and the synonyms strategy.

See **`references/domain_adaptation_guide.md`** for the full reasoning on how to adapt to a new domain.

### Step 1 — Parse the question bank file

```bash
python3 /mnt/skills/user/qe-analysis/scripts/analyze_questions.py \
   /mnt/user-data/uploads/question_bank.txt \
   --output /tmp/qe_analysis.json
```

Auto-detects file format (Format A : FMPM-style headers, B : markdown headers, C : CSV — see `references/parsing_patterns.md`). Emits stats + topic counts + raw question text per topic.

### Step 2 — Gather the 5 required inputs

ASK EXPLICITLY (don't guess) :

```
Pour générer ton document QE haute fréquence, il me faut 5 choses :

1. 📄 Le fichier de banque de questions (.txt) — déjà uploadé ?
2. 📚 Le cours / livre officiel (PDF) — pour vérifier et enrichir (optionnel mais recommandé)
3. 📋 La liste des leçons officielles de cette année
        - Format : "Titre de leçon — Professeur (si applicable)"
4. 🔗 Les liens vers chaque leçon (Google Slides, Drive, ressource web)
5. 📎 Ressources supplémentaires (fiches résumées, autres cours, références faisant autorité)

Précise aussi :
- Le domaine exact (sous-spécialité médicale, branche du droit, ...)
- L'année de l'examen visé
- L'école / le concours
```

Wait for the user. If they only provide some inputs, work with what you have and warn about what's missing.

### Step 3 — Decide the synonyms strategy

Based on the domain identified in Step 0, choose ONE of these paths :

#### Path A — Use an existing example file as-is
If the domain matches an example in `references/synonym_examples/`, use it directly :
- `medical_general_fr.json` — French medical generic vocabulary
- `medical_acronyms_fr.json` — French medical acronyms (SCA, IDM, RGO, MICI, GEU…)
- `legal_fr.json` — French legal vocabulary
- `engineering_en.json` — English engineering vocabulary

You can also pass MULTIPLE synonym files by merging them into one combined file first (most common pattern : medical_general + medical_acronyms).

#### Path B — Extend an existing file
Copy the closest example, then add domain-specific synonyms YOU spot from sampling the question bank :
```bash
cp /mnt/skills/user/qe-analysis/references/synonym_examples/medical_general_fr.json /tmp/synonyms.json
# Edit /tmp/synonyms.json — add specialty-specific pairs
```

#### Path C — Build from scratch
For totally new domains (history, philosophy, niche engineering, etc.), generate a synonyms JSON on the fly :

```json
{
  "domain": "<label>",
  "noise_words": ["<word>", "<word>"],
  "synonyms": [
    ["term_a", "term_a_variant", "term_a_acronym"],
    ["term_b", "term_b_synonym"]
  ]
}
```

Write it to `/tmp/synonyms.json`.

#### Path D — Skip synonyms entirely
If topic names and lesson titles use identical vocabulary (no acronyms, no synonym pairs), the matcher works without any synonyms file — just generic normalization. This is fine but suboptimal.

### Step 4 — Cross-match topics to official lessons

```bash
python3 /mnt/skills/user/qe-analysis/scripts/match_lessons.py \
   /tmp/qe_analysis.json /tmp/lessons.json \
   --synonyms /tmp/synonyms.json \
   --output /tmp/qe_matched.json
```

If the matcher flags ambiguous matches (score 0.75–0.90), **ask the user to confirm** each one :
> "I found 'Tumeur rénale' in your QEs and matched it to 'Tumeurs du rein' at 0.85 — confirm (y/n)?"

### Step 5 — Synthesize per-topic content (the domain heavy lifting)

This is the most domain-dependent step. For each topic (in-program AND HORS) :

1. **Open `qe_matched.json`** and read the `questions_by_topic[topic]` field — every raw question on that topic across all sessions.
2. **Read each question.** Note :
   - TRUE answers across sessions
   - FALSE traps (wrong-but-tempting options)
   - Question stems
3. **Cross-reference with the official source** (Step 2 input 2) and supplementary resources (input 5).
4. **DEDUPLICATE.** If the same concept appears in 5 sessions, list ONE entry with merged TRUE facts and ALL distinct FALSE traps.
5. **Frame the content for the domain** :
   - Diagnostic disciplines → focus on criteria, distinguishing features
   - Clinical specialties → focus on decision trees, indications
   - Mechanism-focused → focus on how it works
   - Procedural → focus on steps + indications
   - Descriptive (histo/anat) → focus on structure, location, origin
   - Legal → focus on conditions of application, exceptions, jurisprudence
   - History → focus on dates, causality
6. **Output structure per topic** (strict JSON shape) :

```json
{
  "subtopic": "Topic stem as a statement :",
  "facts": ["TRUE fact 1", "TRUE fact 2"],
  "warnings": ["FALSE trap 1", "FALSE trap 2"],
  "citations": "Vu : N2017 Q5, R2024 Q3 (2×)"
}
```

**RECOMMENDED — Option B strategy** (dedup + corrections regroupées + FAUX explicites). Why : pitfalls are the highest-value content (what students fail on), repetition signals priority, deduplication keeps the document compact.

### Step 6 — Decide the aide-mémoire structure

The aide-mémoire has 4 conceptual slots :
- `classifications` — formal taxonomies, scoring systems
- `markers` — biomarkers, criteria, indicators
- `pitfalls` — common wrong-but-tempting traps
- `sequences` — causal chains, pathophysiological cascades, procedures

The slot LABELS should adapt to the domain. Examples :

| Domain | classifications | markers | pitfalls | sequences |
|---|---|---|---|---|
| Anapath | OMS classifications | IHC markers | Diagnostic pitfalls | Carcinogenic sequences |
| Cardio | NYHA / CCS / CHA₂DS₂-VASc | Biomarkers + kinetics | ECG misreads | Pathophysiological cascades |
| Gastro | Child-Pugh / Forrest | AFP, CA19-9 | Endoscopic pitfalls | Carcinogenic sequences (Barrett, MICI) |
| Pharmaco | Drug families | Mechanisms of action | Drug-drug interactions | Iconic adverse effects |
| Histo/Anat | Tissue types | Cell-distinctive features | Common confusions | Embryological origins |
| Droit | Classifications des infractions | Éléments constitutifs | Confusions classiques | Chaîne causale de la responsabilité |
| Histoire | Périodisations | Sources & historiographes | Anachronismes | Enchaînements géopolitiques |
| Engineering | Load types | Key formulas | Sign/unit errors | Calculation workflow |

**Don't force 4 slots when only 2-3 fit.** It's fine to leave slots empty if they don't make sense for the domain.

See `references/domain_adaptation_guide.md` for the full per-domain reasoning.

### Step 7 — Ask for output format and generate

```
Synthèse prête. Format de sortie ?
  📄 .txt    — texte brut, léger
  📝 .docx   — Word, formaté, imprimable, liens cliquables
  📕 .pdf    — PDF, identique au docx mais non éditable
  📦 all     — les trois
```

Then build the final `content.json` (see `references/content_schema.md` for the schema) and run :

```bash
# .txt
python3 /mnt/skills/user/qe-analysis/scripts/generate_txt.py \
   /tmp/content.json /mnt/user-data/outputs/{module}_qe_by_claude.ai.txt

# .docx
node /mnt/skills/user/qe-analysis/scripts/generate_docx.js \
   /tmp/content.json /mnt/user-data/outputs/{module}_qe_by_claude.ai.docx

# .pdf (from .docx)
python3 /mnt/skills/user/qe-analysis/scripts/generate_pdf.py \
   /mnt/user-data/outputs/{module}_qe_by_claude.ai.docx \
   /mnt/user-data/outputs/{module}_qe_by_claude.ai.pdf
```

---

## The strict ranking section format

Every entry in PARTIE 3 MUST use this exact header format :

```
═══════════════════════════════════════════════════════════════════
[RANG N] {LESSON TITLE UPPERCASE}
{Professor or — } • ~{avg} Q/examen
📖 {Reference / source — adapt to domain}
📎 Cours officiel : {URL plain in .txt — "Ouvrir le cours officiel ↗" hyperlink in .docx}
═══════════════════════════════════════════════════════════════════
```

In `.txt` the 📎 line shows the actual URL. In `.docx`/`.pdf` it's a clickable hyperlink. Multiple `📎` lines allowed for topics with several linked resources.

## PARTIE 4 disclaimer (mandatory, always)

```
╔══════════════════════════════════════════════════════════════════╗
║  ⚠ DISCLAIMER — À LIRE AVANT D'UTILISER CETTE SECTION ⚠         ║
║                                                                  ║
║  These lessons are NOT in the {YEAR} exam program.               ║
║  Cours annulé — NOT officially scheduled.                        ║
║                                                                  ║
║  USE AT YOUR OWN RISK — BUT GOOD TO KNOW.                        ║
║                                                                  ║
║  Ces topics représentaient historiquement ~{X}% des questions    ║
║  des examens passés.                                             ║
╚══════════════════════════════════════════════════════════════════╝
```

---

## Reference files (load on demand)

- **`references/domain_adaptation_guide.md`** — REASONING guide for adapting to any domain (read this FIRST when domain is unclear)
- **`references/output_format_template.md`** — Exact structure of the output document
- **`references/parsing_patterns.md`** — Question-bank file formats (A/B/C/D)
- **`references/content_schema.md`** — JSON schema for the renderer contract
- **`references/synonym_examples/*.json`** — Starter synonym files (medical, legal, engineering)

## Scripts

- **`scripts/analyze_questions.py`** — Parse the question bank, emit stats + raw text per topic
- **`scripts/match_lessons.py`** — Cross-match (accepts `--synonyms <file>`, domain-agnostic)
- **`scripts/generate_txt.py`** — Render .txt
- **`scripts/generate_docx.js`** — Render .docx (Node.js + docx pkg)
- **`scripts/generate_pdf.py`** — Convert .docx → .pdf (LibreOffice headless)

---

## What NOT to do

- **Don't hardcode domain assumptions.** This skill should work for medical AND non-medical exams. Re-read questions in their actual domain before deciding the structure.
- **Don't skip the domain-identification step.** It drives every subsequent choice.
- **Don't force 4 aide-mémoire slots when only 2 fit.** Leave the irrelevant ones empty.
- **Don't list each question occurrence separately.** DEDUPLICATE — merge into one entry per concept with all distinct corrections.
- **Don't omit the ⚠ FAUX warnings.** They're the highest-value content for exam prep.
- **Don't skip the PARTIE 4 disclaimer.** Always include it, even if PARTIE 4 is empty.
- **Don't invent content.** If you don't have enough source material for a topic, ask the user or mark it `[Content needs verification]`.
- **Don't generate generic study advice.** Every bullet must be a fact, a pitfall, or a citation.
