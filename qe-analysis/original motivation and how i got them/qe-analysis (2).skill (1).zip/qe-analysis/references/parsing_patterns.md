# Parsing Patterns for Question Bank Files

Most question bank files follow one of a handful of recognizable formats. This file documents the common ones and how to detect/handle them.

## Format A — FMPM/Moroccan concours style

Each question is prefixed with a header line that looks like:

```
# Normal 2017 Q1 - tumeurs mammaires
```

Components:
- `#` followed by a space (markdown-style level-1 heading)
- Session name: `Normal`, `Ratt`, `ratt`, `Rattrapage`, `Exceptionnelle`, `Extraordinaire`
- 4-digit year
- `Q` followed by question number (1-2 digits)
- ` - ` separator
- Topic tag (free-form, but reused across questions on the same topic)

### Detection
```bash
grep -c "^# [A-Za-z]* [0-9]\{4\} Q[0-9]\+ - " question_file.txt
```
If this returns >50, it's Format A.

### Extraction
```python
import re
PATTERN_A = re.compile(r'^# (?P<session>[A-Za-zéèêëûô]+) (?P<year>\d{4}) Q(?P<num>\d+) - (?P<topic>.+)$', re.MULTILINE)
```

### Question body
After the header line, the question text follows (usually with options A/B/C/D/E), then a line containing `Correction = ` or similar with the correct option letters.

---

## Format B — Numbered list with topic header

Each topic gets a header block, then numbered questions:

```
## Cancer du sein
1. Le grade SBR comporte :
   A) ...
   B) ...
   Réponse: A, B
2. ...
```

### Detection
Look for `##` markdown headers followed by `^\d+\.` numbered items.

### Extraction
Group questions under the preceding `##` heading.

---

## Format C — CSV/TSV with topic column

A spreadsheet exported to text, columns:
```
year | session | question_id | topic | question_text | answer
```

### Detection
First line contains `topic` or `chapter` as a column header, with `|`, `,`, or `\t` separators.

### Extraction
Use Python's `csv` module with the detected delimiter.

---

## Format D — Plain text, no structure

Just questions separated by blank lines, no topic tags. **This format can't be analyzed by this skill** — you must ask the user to either:
1. Manually tag each question with a topic, OR
2. Use a different tool that can semantically cluster the questions first

Tell the user: "Your question bank has no topic tags. Can you either tag each question by topic, or provide a separate file mapping each question to its topic? Without topics I can't compute the frequency ranking."

---

## Counting sessions

To count distinct exam sessions, take the unique `(session, year)` pairs:

```python
sessions = set()
for match in PATTERN_A.finditer(text):
    sessions.add((match.group('session').lower(), match.group('year')))
total_sessions = len(sessions)
```

Note: case-insensitive session name. `Ratt` and `ratt` should be merged.

---

## Counting questions per topic

```python
from collections import Counter
counts = Counter()
for match in PATTERN_A.finditer(text):
    counts[match.group('topic').strip()] += 1
```

---

## Questions per session (avg)

```python
total_questions = sum(counts.values())
avg_q_per_session = total_questions / total_sessions
```

Typical values: 50 for FMPM concours. Round to nearest integer.

---

## Topic normalization (for cross-match)

Topic tags in the question bank may differ slightly from official lesson titles. Examples:
- `tumeurs mammaires` ↔ `Cancer du sein`
- `tumeur colo-rectale` ↔ `Cancers colo-rectaux`
- `Tumeur rénale` ↔ `Tumeurs du rein`

Normalization rules for matching:
1. Lowercase, strip accents
2. Strip plurals (`s`/`es`)
3. Strip articles (`le/la/les/des/du/de la`)
4. Strip generic prefixes (`tumeurs de la`, `cancer du`, `pathologie de l'`)
5. Compute Levenshtein distance between normalized strings; <0.3 = match

When a topic from the question bank matches NO official lesson, it goes to PARTIE 4 (HORS programme).
When a topic matches multiple official lessons, ask the user to disambiguate.
