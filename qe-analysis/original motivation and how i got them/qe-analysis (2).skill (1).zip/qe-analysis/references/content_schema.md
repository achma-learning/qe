# content.json — Schema Reference

The generator scripts (`generate_txt.py`, `generate_docx.js`, `generate_pdf.py`) all consume a single `content.json` file produced by Claude after the synthesis step. This file is the contract between Claude (the writer) and the renderers.

## Top-level shape

```json
{
  "header": { ... },
  "stats": { ... },
  "ranking_table": [ ... ],
  "averages_table": [ ... ],
  "totals_row": { ... },
  "exam_year": "2026",
  "module_name": "Anatomie pathologique",
  "in_program": [ ... ],
  "hors_program_pct": 37.5,
  "hors_table": [ ... ],
  "hors_program": [ ... ],
  "aide_memoire": { ... },
  "footer": { ... }
}
```

## `header`

```json
{
  "title": "ANATOMOPATHOLOGIE",
  "subtitle": "Fiches QE Haute Fréquence",
  "version": "5",
  "official_doc": "Cours AIO 2026 (858 pages)",
  "year_range": "2017→2025",
  "total_questions": 695,
  "professors_line": "Pr Rais, Pr Rachidi, Pr Rharrassi, Pr Azami — FMPM 2026"
}
```

## `stats`

```json
{
  "total_questions": 695,
  "total_sessions": 14,
  "avg_q_per_exam": 49.6,
  "year_start": "2017",
  "year_end": "2025"
}
```

## `ranking_table` (PARTIE 1)

Array of one row per in-program lesson, sorted by `count` descending:
```json
[
  {"rank": 1, "title": "Cancer du sein", "count": 95, "count_label": "95 Q", "professor": "Pr. Rais"},
  {"rank": 2, "title": "Cancers colo-rectaux", "count": 63, "count_label": "63 Q", "professor": "Pr. Rachidi"},
  ...
]
```

Why both `count` and `count_label`: the label may say `~20 Q` or `Transv.` or `Inclus` for special rows, while `count` is the raw integer for sorting.

## `averages_table` (PARTIE 2)

```json
[
  {"title": "Cancer du sein", "total": "95", "avg": "6.79", "pct": "13.6%"},
  {"title": "Cancers colo-rectaux", "total": "63", "avg": "4.50", "pct": "9.0%"},
  ...
]
```

All values are strings (already formatted). Special values like `transv.` or `~1.40` are allowed.

## `totals_row` (PARTIE 2 summary line)

```json
{
  "label": "TOTAL des leçons officielles",
  "total": "438 Q",
  "avg": "31.3",
  "pct": "62.5%"
}
```

## `in_program` (PARTIE 3 — the bulk content, in rank order)

Array of lesson objects:

```json
[
  {
    "rank": 1,
    "title": "CANCER DU SEIN",
    "professor": "Pr. Rais",
    "freq_label": "~6.79 Q/examen",
    "oms_classification": "Classification OMS 2019 des tumeurs du sein",
    "links": [
      {"label": "Cours officiel", "url": "https://docs.google.com/presentation/d/1g.../edit"}
    ],
    "content": [
      {
        "subtopic": "Le fixateur utilisé pour toute biopsie mammaire :",
        "facts": [
          "le formol tamponné neutre à 4% (= formaldéhyde 10%)",
          "minimiser le temps d'ischémie froide < 1 heure avant fixation"
        ],
        "warnings": [
          "Bouin à éviter ; Glutaraldéhyde = microscopie électronique UNIQUEMENT"
        ],
        "citations": "Vu : N2017 Q5, N2019 Q12, R2023 Q3 (3×)"
      },
      ...
    ]
  },
  ...
]
```

**Rules**:
- `rank` is 1-indexed
- `title` should be UPPERCASE (rendered prominent)
- `freq_label` always starts with `~` and ends with `Q/examen` (or similar)
- `oms_classification` is optional — only set for topics with a formal classification (OMS, AO, FIGO, ...). Will render with the 📖 icon.
- `links` is an array — most topics have ONE link, some (like "Tumeurs hépatiques + Métastases CPI") may have 2 or more
- `content` is the deduplicated medical synthesis. Each entry has:
  - `subtopic`: the question-stem-as-statement, e.g. "Le grade SBR comporte :"
  - `facts`: array of TRUE facts (rendered as `-bullet`)
  - `warnings`: array of FALSE traps / pitfalls (rendered as `-⚠ {text}` in warning color)
  - `citations`: optional string showing where the question appeared (e.g. "Vu : N2017 Q5, R2024 Q3 (2×)")

## `hors_table` (PARTIE 4 table at top)

Same shape as `averages_table` minus the `pct` column, sorted by `count` descending:
```json
[
  {"title": "Méthodes étude/prélèvement organes lymphoïdes", "total": "70 Q", "avg": "5.00"},
  {"title": "Lymphome de Hodgkin", "total": "53 Q", "avg": "3.79"},
  ...
]
```

## `hors_program` (PARTIE 4 — content blocks)

Same shape as `in_program`, but with `num` instead of `rank` and no `professor` (since these are off-program):

```json
[
  {
    "num": 1,
    "title": "MÉTHODES D'ÉTUDE ET DE PRÉLÈVEMENT DES ORGANES LYMPHOÏDES",
    "freq_label": "70 questions — 5.00 Q/examen historique",
    "content": [ ... same structure as in_program content ... ]
  },
  ...
]
```

## `aide_memoire`

Subject-tailored cheatsheet. The structure has fixed slots, but the user-visible labels can vary by module. For anatomopathologie:

```json
{
  "classifications_title": "CLASSIFICATIONS OMS À RETENIR PAR ORGANE",
  "classifications": [
    ["Sein", "OMS 2019"],
    ["Ovaire", "OMS 2020"],
    ["Poumon", "OMS 2021"],
    ["Prostate", "OMS 2022"],
    ["Rein", "OMS 2022"],
    ["Vessie", "OMS 2022"]
  ],
  "markers_title": "MARQUEURS IHC CLÉS",
  "markers": [
    ["P40 / P63 / CK5-6", "Carcinome ÉPIDERMOÏDE"],
    ["TTF-1 / Napsine A / CK7+ / CK20−", "ADK PULMONAIRE primitif"],
    ...
  ],
  "pitfalls_title": "PIÈGES CLASSIQUES DU CONCOURS",
  "pitfalls": [
    "MFK = 4 composantes : kystes + adénose + hyperplasie épithéliale + cicatrice radiaire",
    ...
  ],
  "sequences_title": "SÉQUENCES CARCINOGÈNES CLÉS",
  "sequences": [
    "RGO → EBO (Barrett) → Dysplasie → ADÉNOCARCINOME œsophagien",
    ...
  ]
}
```

For a different module (e.g. cardiologie), the slots can be renamed:
```json
{
  "classifications_title": "CRITÈRES ECG À RETENIR",
  "classifications": [...],
  "markers_title": "BIOMARQUEURS CARDIAQUES ET CINÉTIQUE",
  "markers": [...],
  ...
}
```

The generators just print the title + rows — they don't impose meaning.

## `footer`

```json
{
  "model": "claude-opus-4-7",
  "version": "5",
  "improvements": [
    "PARTIE 3 strictement par rang (1 → N)",
    "Liens cliquables vers cours officiels",
    "PARTIE 4 séparée + disclaimer",
    "Déduplication des questions répétées",
    "FAUX explicites avec ⚠"
  ]
}
```
