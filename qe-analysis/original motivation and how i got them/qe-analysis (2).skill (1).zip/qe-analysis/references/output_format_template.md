# Output Document Format — Strict Template

This is the **exact structure** every generator must produce. All three renderers (`.txt`, `.docx`, `.pdf`) must produce visually equivalent output following this template.

---

## Header block

```
{TITLE_UPPERCASE} — FICHES QE HAUTE FRÉQUENCE
═══════════════════════════════════════════════════════════════════════
Synthèse par Claude.ai — Version {N}
Cross-match : {TOTAL_Q} QEs officielles ({YEAR_RANGE}) × {OFFICIAL_DOC}
{PROFESSORS_LINE}
═══════════════════════════════════════════════════════════════════════
```

---

## PARTIE 1 — Classement des leçons par ordre d'importance décroissante

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PARTIE 1 — CLASSEMENT DES LEÇONS PAR ORDRE D'IMPORTANCE DÉCROISSANTE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Classement basé sur la fréquence réelle dans {TOTAL_Q} QEs ({TOTAL_SESSIONS} sessions).

┌─────┬────────────────────────────────────────────┬───────┬──────────────┐
│ Rang│ Leçon officielle                           │ Total │ Professeur   │
├─────┼────────────────────────────────────────────┼───────┼──────────────┤
│  1  │ {Lesson 1 title}                           │ {N} Q │ {Prof}       │
│  2  │ {Lesson 2 title}                           │ {N} Q │ {Prof}       │
│ ... │ ...                                        │ ...   │ ...          │
└─────┴────────────────────────────────────────────┴───────┴──────────────┘
```

In `.docx`/`.pdf`: use a real Word table, primary color header row, alternating row shading.

---

## PARTIE 2 — Moyenne de questions par leçon par examen

```
┌─────────────────────────────────────────┬────────┬──────────┬─────────┐
│ Leçon officielle                        │ Total  │ Moy/exam │ % d'exam│
├─────────────────────────────────────────┼────────┼──────────┼─────────┤
│ {Lesson 1}                              │ {N}    │ {avg}    │ {pct}%  │
│ ...                                     │ ...    │ ...      │ ...     │
├─────────────────────────────────────────┼────────┼──────────┼─────────┤
│ TOTAL des leçons officielles            │ {SUM}  │ {avg}    │ {pct}%  │
└─────────────────────────────────────────┴────────┴──────────┴─────────┘
```

Calculations:
- `Moy/exam = Total / TOTAL_SESSIONS` (round to 2 decimals)
- `% d'exam = (Moy/exam / AVG_Q_PER_EXAM) × 100` (round to 1 decimal)

---

## PARTIE 3 — Questions les plus fréquentes (ordre strict par rang)

**STRICT ASCENDING RANK ORDER: 1, 2, 3, …, N.** No grouping by professor.

### Per-lesson block — STRICT FORMAT

```
═══════════════════════════════════════════════════════════════════
[RANG {N}] {LESSON TITLE UPPERCASE}
{Professor} • ~{avg} Q/examen
📖 {Reference / OMS classification / source}
📎 Cours officiel : {Ouvrir le cours officiel ↗ — link / URL in txt}
═══════════════════════════════════════════════════════════════════
```

Example:
```
═══════════════════════════════════════════════════════════════════
[RANG 1] CANCER DU SEIN
Pr. Rais • ~6.79 Q/examen
📖 Classification OMS 2019 des tumeurs du sein
📎 Cours officiel : Ouvrir le cours officiel ↗
═══════════════════════════════════════════════════════════════════
```

**Rendering rules per format:**

- **`.txt`** — replace `Ouvrir le cours officiel ↗` with the actual URL:
  ```
  📎 Cours officiel : https://docs.google.com/presentation/d/1gye.../edit
  ```

- **`.docx`** — render `Ouvrir le cours officiel ↗` as a clickable `ExternalHyperlink` pointing to the URL. Underline + link color.

- **`.pdf`** — generated from .docx, preserves the clickable link.

For lessons with multiple linked sub-courses (e.g. Rang 6 = Tumeurs hépatiques + Démarche CPI), repeat the `📎` line:
```
📎 Cours Tumeurs hépatiques : Ouvrir ↗
📎 Cours Démarche CPI : Ouvrir ↗
```

### Per-topic content (the bulk of PARTIE 3)

After the lesson header, the deduplicated content follows:

```
* {Subtopic / question-stem-as-statement} :
-{TRUE fact 1}
-{TRUE fact 2}
-⚠ {FAUX trap 1}
-⚠ {FAUX trap 2}
📋 Vu : N2017 Q5, R2024 Q3 (2×)         [optional citation line]
```

**Rendering rules:**
- The `* {subtopic} :` line is bold + underlined (in .docx/.pdf, accent color)
- `-{fact}` lines are bullet points (use Word's bullet list in .docx)
- `-⚠ {warning}` lines are bullets but text in **warning color (amber #B45309)** and italic
- `📋 Vu : ...` citation line (optional) is small, gray, italic

**RECOMMENDED — Option B strategy (deduplication):**
- If the same question appears in 5 sessions, list it ONCE
- Merge all TRUE answers seen across sessions into the `facts` array (no duplicates)
- Surface ALL distinct FALSE answers seen into the `warnings` array
- Citations are optional but very useful for >2 occurrences

---

## PARTIE 4 — Topics HORS leçons officielles {YEAR} (cours annulé)

**Mandatory** even if empty. Always include the disclaimer box first.

### Disclaimer (mandatory, exact text)

```
╔══════════════════════════════════════════════════════════════════╗
║  ⚠ DISCLAIMER — À LIRE AVANT D'UTILISER CETTE SECTION ⚠         ║
║                                                                  ║
║  These lessons are NOT in the {YEAR} exam program.               ║
║  Cours annulé — NOT officially scheduled.                        ║
║                                                                  ║
║  USE AT YOUR OWN RISK — BUT GOOD TO KNOW.                        ║
║                                                                  ║
║  Ces topics représentaient historiquement ~{X}% des questions    ║
║  des examens passés. S'ils ne sont PAS au programme cette année, ║
║  ils peuvent malgré tout apparaître en :                         ║
║   • question résiduelle ou rattrapage                            ║
║   • recyclage de dernière minute                                 ║
║   • culture générale médicale                                    ║
╚══════════════════════════════════════════════════════════════════╝
```

In `.docx`/`.pdf`: render as a **red-bordered danger box** with white background, danger-red text.

### HORS topics table

```
┌─────────────────────────────────────────┬────────┬──────────┐
│ Topic (hors programme {YEAR})           │ Total  │ Moy/exam │
├─────────────────────────────────────────┼────────┼──────────┤
│ {HORS topic 1}                          │ {N}    │ {avg}    │
│ ...                                     │ ...    │ ...      │
└─────────────────────────────────────────┴────────┴──────────┘
```

Topics ordered by **count descending**.

### Per-topic HORS block

```
═══════════════════════════════════════════════════════════════════
[HORS-{n}] {TOPIC TITLE UPPERCASE}
{N} questions — {avg} Q/examen historique
═══════════════════════════════════════════════════════════════════

* {Subtopic} :
-{fact}
-⚠ {trap}
...
```

Same content structure as PARTIE 3, but no `📖` / `📎` (since these are off-program).

---

## Aide-mémoire (final cheatsheet — subject-tailored)

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
AIDE-MÉMOIRE FINAL — HIGH-YIELD CONCOURS {MODULE_NAME}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

** {classifications_title} **
{Row 1 label}   →   {Row 1 value}
{Row 2 label}   →   {Row 2 value}
...

** {markers_title} **
{Marker pattern}   →   {Indication}
...

** {pitfalls_title} **
- {Pitfall 1}
- {Pitfall 2}
...

** {sequences_title} **
{Sequence 1}
{Sequence 2}
...
```

The titles vary by module (Anatomopathologie → OMS classifications + IHC markers ; Cardiologie → critères ECG + biomarqueurs ; etc.).

---

## Footer

```
═══════════════════════════════════════════════════════════════════════
Généré par Claude.ai ({MODEL_ID}) — Version {N}
Cross-match {TOTAL_Q} QEs officielles × {OFFICIAL_DOC}
{PROFESSORS_LINE}

Améliorations Version {N} :
  ✓ {improvement 1}
  ✓ {improvement 2}
  ...
═══════════════════════════════════════════════════════════════════════
```

---

## Format-specific rendering checklist

### `.txt`
- [x] Box-drawing characters (`─ ━ │ ┌ ┐ └ ┘ ╔ ╗ ╝ ╚ ║`) for tables and banners
- [x] Plain markers (`-`, `*`, `⚠`, `📎`, `📖`, `📋`)
- [x] URLs printed verbatim in `📎` lines (no hyperlinks possible)
- [x] Max line width 80 chars where possible

### `.docx`
- [x] Real Word tables (no ASCII art)
- [x] Topic headings (`* Foo :`): bold + underline, accent color
- [x] Facts: numbered/bulleted list
- [x] Pitfalls (`⚠`): bullet, warning color, italic
- [x] Source (`📖`) and link (`📎`): centered, italic, gray
- [x] Links: real `ExternalHyperlink` (clickable)
- [x] Section banners (PARTIE 1, 2, 3, ...): full-width filled rectangle, white bold on primary color
- [x] PARTIE 4 banner: filled rectangle, **danger red background**
- [x] Disclaimer box: bordered, red border, red text
- [x] Page breaks between major sections

### `.pdf`
- [x] Generated via LibreOffice from the .docx — same styling preserved
- [x] Verify hyperlinks remain clickable in the PDF
