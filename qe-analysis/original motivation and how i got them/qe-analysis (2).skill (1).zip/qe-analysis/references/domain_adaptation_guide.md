# Domain Adaptation Guide

The skill is **truly domain-agnostic**. It encodes a procedure (parse → match → synthesize → render), not domain knowledge. When triggered, Claude must figure out the optimal approach for the specific subject being analyzed.

This file is a **reasoning guide** for that adaptation — not a list of fixed templates.

---

## Step 1 — Identify the domain

Before doing anything else, identify what subject the question bank belongs to. Signals :

- **Filename** — `cardio_QE.txt`, `Anapath 2.txt`, `droit_civil_concours.txt`, `physics_finals.txt`
- **Sample content** — read 5-10 questions. The vocabulary tells you the domain (medical jargon vs legal terminology vs engineering formulas).
- **Topic names** — if topics are "Cancer du sein, Tumeurs hépatiques…" it's clearly medical oncology.
- **Professor names** in the lessons list — often tied to a department.
- **Direct ask** — if any signal is ambiguous, just ask the user :
  > "Pour cette banque de questions, quel est le domaine exact ? (cardiologie, droit civil, mécanique des fluides, histoire moderne, ...)"

Set `content.module_name` in the final JSON to the domain identified.

---

## Step 2 — Decide whether you need a synonyms file

The matcher (`scripts/match_lessons.py`) can run **without** a synonyms file — it'll use generic normalization (lowercase, accent-strip, stem, Jaccard). This works fine when topic names and lesson titles use the **same words**.

You **need** synonyms when the question bank and the official lessons use **different vocabulary for the same concept**. Examples :

- Medical : QE says "tumeur mammaire", official lesson says "cancer du sein" → need `{mammaire, sein}` synonym
- Legal : QE says "responsabilité civile", lesson says "RC" → need `{rc, responsabilité civile}` synonym
- Engineering : QE says "moment fléchissant", lesson says "flexion" → need `{moment flechissant, flexion}` synonym

### Approach

1. **Check the `references/synonym_examples/` folder.** If a file matches your domain, load it directly.
2. **If none fits exactly**, copy the closest one and **extend it on the fly** with the synonyms YOU spot from sampling 10-20 question/lesson title pairs.
3. **If the domain is totally new** (non-medical, no example), **generate a new synonyms JSON from scratch** based on your domain knowledge. Write it to `/tmp/synonyms.json` and pass `--synonyms /tmp/synonyms.json` to the matcher.

### Synonyms file schema (concise)

```json
{
  "domain": "<human-readable label>",
  "noise_words": ["word1", "word2", "..."],
  "synonyms": [
    ["term_a", "term_a_variant", "term_a_acronym"],
    ["term_b", "term_b_synonym"]
  ]
}
```

- **noise_words** = words that appear so frequently they don't help discrimination. E.g. medical : "tumeur", "cancer", "pathologie". Legal : "article", "loi", "code". History : "période", "siècle".
- **synonyms** = list of sublists. Each sublist groups equivalent terms (synonyms, variants, plurals, acronyms, technical/lay equivalents).

---

## Step 3 — Decide the optimal aide-mémoire structure for THIS domain

The aide-mémoire (final cheatsheet) has 4 conceptual slots :
- `classifications` — formal scoring systems, staging schemes, taxonomies
- `markers` — biomarkers, indicators, criteria
- `pitfalls` — common wrong-but-tempting answers
- `sequences` — causal chains, pathophysiological cascades, procedural workflows

But the SLOT NAMES should adapt to the domain. Reason about what would be most useful :

| Domain | classifications | markers | pitfalls | sequences |
|---|---|---|---|---|
| Anapath | OMS classifications | IHC markers | Diagnostic pitfalls | Carcinogenic sequences |
| Cardiologie | NYHA / CCS / CHA₂DS₂-VASc | Biomarkers + kinetics | ECG misreads | Pathophysiological cascades |
| Gastrologie | Child-Pugh / Forrest | AFP, CA19-9, calprotectine | Endoscopic pitfalls | Carcinogenic sequences (Barrett, MICI) |
| Traumatologie | AO/Garden/Schatzker | Imaging keys | Indication chirurgicale traps | Mechanism of injury |
| Gynécologie | FIGO / ACR-BIRADS | β-hCG, CA125, BRCA | Dépistage pitfalls | HPV→CIN→cancer |
| Pharmacologie | Drug families | Mechanism of action | Drug-drug interactions | Iconic adverse effects |
| Histologie | Tissue types | Cell-distinctive features | Common confusions | Embryological origins |
| **Droit pénal** | **Classifications des infractions** | **Éléments constitutifs** | **Confusions classiques** | **Chaîne causale de la responsabilité** |
| **Histoire moderne** | **Périodisations** | **Sources et historiographes** | **Anachronismes fréquents** | **Enchaînements géopolitiques** |
| **Mécanique** | **Types de chargement** | **Formules clés** | **Erreurs de signe / unité** | **Démarche de calcul** |

**Don't force a domain into a medical-oncology shape.** If a domain doesn't have "classifications" per se, rename the slot — e.g. for philosophy : "courants de pensée" instead of "classifications". The renderer just prints the title + rows.

---

## Step 4 — Decide the content tone per topic

When synthesizing the high-yield content for each topic (Step 4 of the main workflow), adapt the framing :

- **Diagnostic disciplines** (anapath, radiology) → focus on **criteria** : what distinguishes A from B, IHC profile, specific stains, mandatory features
- **Clinical specialties** (cardio, gastro, traumato) → focus on **decision trees** : when to image, when to operate, drug of choice
- **Mechanism-focused** (pharmaco, physiology) → focus on **how it works** : MOA, kinetics, side-effect mechanism
- **Procedural** (surgery, anesthesia) → focus on **steps + indications** : conditions for procedure, contraindications, complications
- **Descriptive** (histology, anatomy, embryology) → focus on **structural detail** : location, layers, cell types, origin
- **Legal** → focus on **conditions of application** : éléments constitutifs, exceptions, jurisprudence clé
- **History/Politics** → focus on **dates + causal explanations** : what triggered what, who/where/when

The format (fact bullets + ⚠ pitfalls + 📋 citations) stays the same. Only the WORDING shifts.

---

## Step 5 — Decide the `📖` source line wording per lesson

The `📖` line in each `[RANG N]` block introduces the topic's reference source. Choose what's natural for the domain :

| Domain | Typical `📖` line |
|---|---|
| Anapath | `Classification OMS 2022 des tumeurs rénales` |
| Cardio | `Recommandations ESC 2023 — Insuffisance cardiaque` |
| Gastro | `Conférence de consensus AFEF 2019 — Cirrhose` |
| Traumato | `Classification AO/OTA 2018` |
| Gynéco | `Recommandations CNGOF 2021` |
| Pharmaco | `Vidal 2024 + RCP` |
| Médecine interne | `Recommandations HAS / EULAR / SFR` |
| Droit | `Code civil art. 1240 ; Cass. civ. 2e, 17 mars 2011` |
| Histoire | `Période XVIIᵉ-XVIIIᵉ siècle — historiographie braudélienne` |

If you don't know what's authoritative for the domain, **ask the user** : "Quelle est la référence faisant autorité dans ce domaine pour le concours ?"

---

## Step 6 — When the domain is completely novel

If you've never seen the domain before (e.g. user uploads questions on a niche industrial process or an obscure regional history exam) :

1. Do **NOT** force-fit a medical or legal template.
2. **Sample broadly** — read 30+ questions from the bank to learn the vocabulary.
3. **Ask the user** explicitly what taxonomy / classification / scoring framework is authoritative in this field.
4. **Build the synonyms file** from scratch with the most discriminating terms you find.
5. **Adapt the aide-mémoire slot names** to whatever conceptual structure the user confirms is meaningful.

The skill's scripts are **just renderers and matchers** — they don't impose subject matter. Whatever JSON you feed them, they'll render.

---

## Failure modes to avoid

- ❌ **Hardcoding domain assumptions.** If you find yourself thinking "well, in anapath I'd say…" for a cardiology bank, stop. Re-read questions in their actual domain.
- ❌ **Forcing 4 slots when only 2 fit.** It's fine for the aide-mémoire to have just `classifications` and `pitfalls` if `markers` and `sequences` don't make sense.
- ❌ **Inventing medical jargon for non-medical domains.** The output document should sound natural to a domain expert.
- ❌ **Skipping the synonyms file when matching fails.** If the matcher returns >20% HORS-program topics for a single-specialty bank, it's probably a vocabulary mismatch — build a synonyms file.
- ❌ **Defaulting to French medical terms.** This skill must work in English, in legal French, in any language the user provides.

---

## Examples of synonym files you can ship in `references/synonym_examples/`

The skill includes a few starter files. Use them as templates, not as final products :

- `medical_general_fr.json` — broad French medical vocabulary (organs, specialties, common acronyms)
- `medical_acronyms_fr.json` — French medical acronym → full-name mappings (SCA, IDM, RGO, MICI, GEU…)
- `legal_fr.json` — French legal vocabulary (responsabilité civile, droit pénal, contrats…)
- `engineering_en.json` — general engineering vocabulary (stress, strain, moment, etc.)

For domains not covered, **generate your own** based on what you see in the question bank.
